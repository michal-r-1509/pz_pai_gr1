var _batch_mapper_8java =
[
    [ "com.pz1.pai.batch.tool.BatchMapper", "classcom_1_1pz1_1_1pai_1_1batch_1_1tool_1_1_batch_mapper.html", "classcom_1_1pz1_1_1pai_1_1batch_1_1tool_1_1_batch_mapper" ]
];