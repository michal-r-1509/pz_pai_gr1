var _order_repository_8java =
[
    [ "com.pz1.pai.order.repository.OrderRepository", "interfacecom_1_1pz1_1_1pai_1_1order_1_1repository_1_1_order_repository.html", "interfacecom_1_1pz1_1_1pai_1_1order_1_1repository_1_1_order_repository" ]
];