var namespacecom_1_1pz1_1_1pai_1_1batch_1_1controller =
[
    [ "BatchController", "classcom_1_1pz1_1_1pai_1_1batch_1_1controller_1_1_batch_controller.html", null ]
];