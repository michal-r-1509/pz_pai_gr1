var classcom_1_1pz1_1_1pai_1_1exceptions_1_1_global_exception_handler =
[
    [ "elementConflictHandler", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_global_exception_handler.html#a2ac3551b16e3344dfcb0ed13ef9fbb80", null ],
    [ "elementNotFoundHandler", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_global_exception_handler.html#aa83d2adef0c1bdeb63d1ea4ffb88c25a", null ],
    [ "invalidTaxpayerIdentityNumberHandler", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_global_exception_handler.html#a360bf98ed78fb2ddcf7d8ad64d0d39b9", null ],
    [ "orderUndoneHandler", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_global_exception_handler.html#aec424a3c35a6d496804e8c607f75099d", null ]
];