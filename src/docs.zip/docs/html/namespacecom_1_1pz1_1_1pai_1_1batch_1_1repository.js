var namespacecom_1_1pz1_1_1pai_1_1batch_1_1repository =
[
    [ "BatchRepository", "interfacecom_1_1pz1_1_1pai_1_1batch_1_1repository_1_1_batch_repository.html", "interfacecom_1_1pz1_1_1pai_1_1batch_1_1repository_1_1_batch_repository" ]
];