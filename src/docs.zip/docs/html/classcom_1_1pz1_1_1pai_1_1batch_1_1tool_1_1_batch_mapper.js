var classcom_1_1pz1_1_1pai_1_1batch_1_1tool_1_1_batch_mapper =
[
    [ "toBatch", "classcom_1_1pz1_1_1pai_1_1batch_1_1tool_1_1_batch_mapper.html#a7d055bfd0dd42871de742b87b842a8a3", null ],
    [ "toBatchDnPrintResponse", "classcom_1_1pz1_1_1pai_1_1batch_1_1tool_1_1_batch_mapper.html#a2c62d40263a43424818c68bc2d99896b", null ],
    [ "toBatchResponse", "classcom_1_1pz1_1_1pai_1_1batch_1_1tool_1_1_batch_mapper.html#a32678247cac320961548c73cab340614", null ],
    [ "updateBatch", "classcom_1_1pz1_1_1pai_1_1batch_1_1tool_1_1_batch_mapper.html#a84ef8eb89ea6c143577cc0a98dd4dc27", null ]
];