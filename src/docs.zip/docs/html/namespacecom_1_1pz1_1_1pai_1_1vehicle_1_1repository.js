var namespacecom_1_1pz1_1_1pai_1_1vehicle_1_1repository =
[
    [ "VehicleRepository", "interfacecom_1_1pz1_1_1pai_1_1vehicle_1_1repository_1_1_vehicle_repository.html", "interfacecom_1_1pz1_1_1pai_1_1vehicle_1_1repository_1_1_vehicle_repository" ]
];