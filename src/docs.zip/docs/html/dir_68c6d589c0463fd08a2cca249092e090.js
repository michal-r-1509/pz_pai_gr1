var dir_68c6d589c0463fd08a2cca249092e090 =
[
    [ "BaseEntity.java", "_base_entity_8java.html", "_base_entity_8java" ]
];