var interfacecom_1_1pz1_1_1pai_1_1schedule_1_1service_1_1_schedule_service =
[
    [ "getScheduleByVehicleIdAndDate", "interfacecom_1_1pz1_1_1pai_1_1schedule_1_1service_1_1_schedule_service.html#ae329170e0623f609807350213a360eb2", null ],
    [ "saveSchedule", "interfacecom_1_1pz1_1_1pai_1_1schedule_1_1service_1_1_schedule_service.html#af386f1dc2c7862eec35f3e94fb251b59", null ],
    [ "saveSchedule", "interfacecom_1_1pz1_1_1pai_1_1schedule_1_1service_1_1_schedule_service.html#a154428c4e763b4d3814ff7e8066f735a", null ]
];