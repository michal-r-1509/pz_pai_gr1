var hierarchy =
[
    [ "com.pz1.pai.archive.controller.ArchiveController", "classcom_1_1pz1_1_1pai_1_1archive_1_1controller_1_1_archive_controller.html", null ],
    [ "com.pz1.pai.archive.tool.ArchiveMapper", "classcom_1_1pz1_1_1pai_1_1archive_1_1tool_1_1_archive_mapper.html", null ],
    [ "com.pz1.pai.archive.service.ArchiveService", "classcom_1_1pz1_1_1pai_1_1archive_1_1service_1_1_archive_service.html", null ],
    [ "com.pz1.pai.shared.BaseEntity", "classcom_1_1pz1_1_1pai_1_1shared_1_1_base_entity.html", [
      [ "com.pz1.pai.archive.domain.ArchivedBatch", "classcom_1_1pz1_1_1pai_1_1archive_1_1domain_1_1_archived_batch.html", null ],
      [ "com.pz1.pai.batch.domain.Batch", "classcom_1_1pz1_1_1pai_1_1batch_1_1domain_1_1_batch.html", null ],
      [ "com.pz1.pai.client.domain.Client", "classcom_1_1pz1_1_1pai_1_1client_1_1domain_1_1_client.html", null ],
      [ "com.pz1.pai.order.domain.Order", "classcom_1_1pz1_1_1pai_1_1order_1_1domain_1_1_order.html", null ],
      [ "com.pz1.pai.schedule.domain.Schedule", "classcom_1_1pz1_1_1pai_1_1schedule_1_1domain_1_1_schedule.html", null ],
      [ "com.pz1.pai.vehicle.domain.Vehicle", "classcom_1_1pz1_1_1pai_1_1vehicle_1_1domain_1_1_vehicle.html", null ]
    ] ],
    [ "com.pz1.pai.batch.controller.BatchController", "classcom_1_1pz1_1_1pai_1_1batch_1_1controller_1_1_batch_controller.html", null ],
    [ "com.pz1.pai.batch.dto.BatchDnPrintDTO", "classcom_1_1pz1_1_1pai_1_1batch_1_1dto_1_1_batch_dn_print_d_t_o.html", null ],
    [ "com.pz1.pai.batch.tool.BatchMapper", "classcom_1_1pz1_1_1pai_1_1batch_1_1tool_1_1_batch_mapper.html", null ],
    [ "com.pz1.pai.batch.dto.BatchRequestDTO", "classcom_1_1pz1_1_1pai_1_1batch_1_1dto_1_1_batch_request_d_t_o.html", null ],
    [ "com.pz1.pai.batch.dto.BatchResponseDTO", "classcom_1_1pz1_1_1pai_1_1batch_1_1dto_1_1_batch_response_d_t_o.html", null ],
    [ "com.pz1.pai.batch.service.BatchService", "interfacecom_1_1pz1_1_1pai_1_1batch_1_1service_1_1_batch_service.html", [
      [ "com.pz1.pai.batch.service.BatchServiceImpl", "classcom_1_1pz1_1_1pai_1_1batch_1_1service_1_1_batch_service_impl.html", null ]
    ] ],
    [ "com.pz1.pai.batch.tool.BatchValidator", "classcom_1_1pz1_1_1pai_1_1batch_1_1tool_1_1_batch_validator.html", null ],
    [ "com.pz1.pai.client.controller.ClientController", "classcom_1_1pz1_1_1pai_1_1client_1_1controller_1_1_client_controller.html", null ],
    [ "com.pz1.pai.client.tool.ClientMapper", "classcom_1_1pz1_1_1pai_1_1client_1_1tool_1_1_client_mapper.html", null ],
    [ "com.pz1.pai.client.service.ClientService", "interfacecom_1_1pz1_1_1pai_1_1client_1_1service_1_1_client_service.html", [
      [ "com.pz1.pai.client.service.ClientServiceImpl", "classcom_1_1pz1_1_1pai_1_1client_1_1service_1_1_client_service_impl.html", null ]
    ] ],
    [ "com.pz1.pai.client.tool.ClientType", "enumcom_1_1pz1_1_1pai_1_1client_1_1tool_1_1_client_type.html", null ],
    [ "com.pz1.pai.order.tool.OrderMapper", "classcom_1_1pz1_1_1pai_1_1order_1_1tool_1_1_order_mapper.html", null ],
    [ "com.pz1.pai.order.dto.OrderRequestDTO", "classcom_1_1pz1_1_1pai_1_1order_1_1dto_1_1_order_request_d_t_o.html", null ],
    [ "com.pz1.pai.order.dto.OrderResponseDTO", "classcom_1_1pz1_1_1pai_1_1order_1_1dto_1_1_order_response_d_t_o.html", null ],
    [ "com.pz1.pai.order.service.OrderService", "interfacecom_1_1pz1_1_1pai_1_1order_1_1service_1_1_order_service.html", [
      [ "com.pz1.pai.order.service.OrderServiceImpl", "classcom_1_1pz1_1_1pai_1_1order_1_1service_1_1_order_service_impl.html", null ]
    ] ],
    [ "com.pz1.pai.order.event.OrderStatus", "classcom_1_1pz1_1_1pai_1_1order_1_1event_1_1_order_status.html", null ],
    [ "com.pz1.pai.PaiApplication", "classcom_1_1pz1_1_1pai_1_1_pai_application.html", null ],
    [ "RuntimeException", null, [
      [ "com.pz1.pai.exceptions.ElementConflictException", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_element_conflict_exception.html", null ],
      [ "com.pz1.pai.exceptions.ElementNotFoundException", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_element_not_found_exception.html", null ],
      [ "com.pz1.pai.exceptions.IllegalOperationException", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_illegal_operation_exception.html", null ],
      [ "com.pz1.pai.exceptions.TaxpayerIdentityNumberException", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_taxpayer_identity_number_exception.html", null ]
    ] ],
    [ "com.pz1.pai.batch.tool.ScheduleMapper", "classcom_1_1pz1_1_1pai_1_1batch_1_1tool_1_1_schedule_mapper.html", null ],
    [ "com.pz1.pai.schedule.service.ScheduleService", "interfacecom_1_1pz1_1_1pai_1_1schedule_1_1service_1_1_schedule_service.html", [
      [ "com.pz1.pai.schedule.service.ScheduleServiceImpl", "classcom_1_1pz1_1_1pai_1_1schedule_1_1service_1_1_schedule_service_impl.html", null ]
    ] ],
    [ "com.pz1.pai.vehicle.tool.VehicleMapper", "classcom_1_1pz1_1_1pai_1_1vehicle_1_1tool_1_1_vehicle_mapper.html", null ],
    [ "com.pz1.pai.vehicle.dto.VehicleRequestDTO", "classcom_1_1pz1_1_1pai_1_1vehicle_1_1dto_1_1_vehicle_request_d_t_o.html", null ],
    [ "com.pz1.pai.vehicle.service.VehicleService", "interfacecom_1_1pz1_1_1pai_1_1vehicle_1_1service_1_1_vehicle_service.html", [
      [ "com.pz1.pai.vehicle.service.VehicleServiceImpl", "classcom_1_1pz1_1_1pai_1_1vehicle_1_1service_1_1_vehicle_service_impl.html", null ]
    ] ],
    [ "com.pz1.pai.vehicle.domain.VehicleType", "enumcom_1_1pz1_1_1pai_1_1vehicle_1_1domain_1_1_vehicle_type.html", null ],
    [ "JpaRepository", null, [
      [ "com.pz1.pai.archive.repository.ArchiveRepository", "interfacecom_1_1pz1_1_1pai_1_1archive_1_1repository_1_1_archive_repository.html", null ],
      [ "com.pz1.pai.batch.repository.BatchRepository", "interfacecom_1_1pz1_1_1pai_1_1batch_1_1repository_1_1_batch_repository.html", null ],
      [ "com.pz1.pai.client.repository.ClientRepository", "interfacecom_1_1pz1_1_1pai_1_1client_1_1repository_1_1_client_repository.html", null ],
      [ "com.pz1.pai.order.repository.OrderRepository", "interfacecom_1_1pz1_1_1pai_1_1order_1_1repository_1_1_order_repository.html", null ],
      [ "com.pz1.pai.schedule.repository.ScheduleRepository", "interfacecom_1_1pz1_1_1pai_1_1schedule_1_1repository_1_1_schedule_repository.html", null ],
      [ "com.pz1.pai.vehicle.repository.VehicleRepository", "interfacecom_1_1pz1_1_1pai_1_1vehicle_1_1repository_1_1_vehicle_repository.html", null ]
    ] ],
    [ "ResponseEntityExceptionHandler", null, [
      [ "com.pz1.pai.exceptions.GlobalExceptionHandler", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_global_exception_handler.html", null ]
    ] ]
];