var dir_d571a74363e22328213b0351552924a0 =
[
    [ "ArchivedBatch.java", "_archived_batch_8java.html", "_archived_batch_8java" ]
];