var classcom_1_1pz1_1_1pai_1_1exceptions_1_1_element_not_found_exception =
[
    [ "ElementNotFoundException", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_element_not_found_exception.html#adfdb2d87bdda8f3ea1943e8d85b5520a", null ],
    [ "getId", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_element_not_found_exception.html#a6801a5d4d2d85e5d388f7cf866418c1c", null ]
];