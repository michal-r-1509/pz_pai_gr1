var namespacecom_1_1pz1_1_1pai_1_1vehicle_1_1domain =
[
    [ "Vehicle", "classcom_1_1pz1_1_1pai_1_1vehicle_1_1domain_1_1_vehicle.html", null ],
    [ "VehicleType", "enumcom_1_1pz1_1_1pai_1_1vehicle_1_1domain_1_1_vehicle_type.html", "enumcom_1_1pz1_1_1pai_1_1vehicle_1_1domain_1_1_vehicle_type" ]
];