var classcom_1_1pz1_1_1pai_1_1vehicle_1_1tool_1_1_vehicle_mapper =
[
    [ "existVehicleValidation", "classcom_1_1pz1_1_1pai_1_1vehicle_1_1tool_1_1_vehicle_mapper.html#ae76d3a6a6b0b09a4a41ca066c4b8d57c", null ],
    [ "newVehicleValidation", "classcom_1_1pz1_1_1pai_1_1vehicle_1_1tool_1_1_vehicle_mapper.html#adfa0007eeccd2931a28424f644bfeb5a", null ]
];