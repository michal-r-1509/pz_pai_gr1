var interfacecom_1_1pz1_1_1pai_1_1order_1_1repository_1_1_order_repository =
[
    [ "existsOrderByClient_Id", "interfacecom_1_1pz1_1_1pai_1_1order_1_1repository_1_1_order_repository.html#a17afc593f1ef067f7c62887f05dd1963", null ]
];