var interfacecom_1_1pz1_1_1pai_1_1client_1_1repository_1_1_client_repository =
[
    [ "existsClientByName", "interfacecom_1_1pz1_1_1pai_1_1client_1_1repository_1_1_client_repository.html#ad8222c4b64b078833573636d58ca6c20", null ],
    [ "existsClientByNameAndIdIsNot", "interfacecom_1_1pz1_1_1pai_1_1client_1_1repository_1_1_client_repository.html#a5cf5147b06aa2c1489cbaf3090bfaf72", null ],
    [ "existsClientByTaxpayerIdentNo", "interfacecom_1_1pz1_1_1pai_1_1client_1_1repository_1_1_client_repository.html#a1390819c5b7c3361ba52eb91be38149f", null ]
];