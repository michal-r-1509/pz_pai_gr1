var dir_51fc622cc8cfb677c28f02a5f36a3b80 =
[
    [ "ElementConflictException.java", "_element_conflict_exception_8java.html", "_element_conflict_exception_8java" ],
    [ "ElementNotFoundException.java", "_element_not_found_exception_8java.html", "_element_not_found_exception_8java" ],
    [ "GlobalExceptionHandler.java", "_global_exception_handler_8java.html", "_global_exception_handler_8java" ],
    [ "IllegalOperationException.java", "_illegal_operation_exception_8java.html", "_illegal_operation_exception_8java" ],
    [ "TaxpayerIdentityNumberException.java", "_taxpayer_identity_number_exception_8java.html", "_taxpayer_identity_number_exception_8java" ]
];