var _batch_request_d_t_o_8java =
[
    [ "com.pz1.pai.batch.dto.BatchRequestDTO", "classcom_1_1pz1_1_1pai_1_1batch_1_1dto_1_1_batch_request_d_t_o.html", null ]
];