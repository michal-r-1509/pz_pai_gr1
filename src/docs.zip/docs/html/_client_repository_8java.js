var _client_repository_8java =
[
    [ "com.pz1.pai.client.repository.ClientRepository", "interfacecom_1_1pz1_1_1pai_1_1client_1_1repository_1_1_client_repository.html", "interfacecom_1_1pz1_1_1pai_1_1client_1_1repository_1_1_client_repository" ]
];