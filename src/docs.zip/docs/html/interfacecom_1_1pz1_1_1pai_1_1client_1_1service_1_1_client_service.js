var interfacecom_1_1pz1_1_1pai_1_1client_1_1service_1_1_client_service =
[
    [ "deleteClient", "interfacecom_1_1pz1_1_1pai_1_1client_1_1service_1_1_client_service.html#a27a0379829ed29b42fb762cce35d1556", null ],
    [ "getAllClients", "interfacecom_1_1pz1_1_1pai_1_1client_1_1service_1_1_client_service.html#a8d195df4b628ff8aa7c34dedff3c3ec0", null ],
    [ "getAllClients", "interfacecom_1_1pz1_1_1pai_1_1client_1_1service_1_1_client_service.html#aa0ec594c16107cde9c38632e08fc3897", null ],
    [ "getClient", "interfacecom_1_1pz1_1_1pai_1_1client_1_1service_1_1_client_service.html#abce5d06c926a9be5f1dbf0097bc6b565", null ],
    [ "saveClient", "interfacecom_1_1pz1_1_1pai_1_1client_1_1service_1_1_client_service.html#aeca59537324531ac328120450ac54dcc", null ],
    [ "updateClient", "interfacecom_1_1pz1_1_1pai_1_1client_1_1service_1_1_client_service.html#ae568b5ca6f489fb2de5d17ac48521673", null ]
];