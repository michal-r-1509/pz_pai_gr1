var interfacecom_1_1pz1_1_1pai_1_1batch_1_1repository_1_1_batch_repository =
[
    [ "findAllByOrderId", "interfacecom_1_1pz1_1_1pai_1_1batch_1_1repository_1_1_batch_repository.html#aedf2476adc7275d7d850add60836ae90", null ]
];