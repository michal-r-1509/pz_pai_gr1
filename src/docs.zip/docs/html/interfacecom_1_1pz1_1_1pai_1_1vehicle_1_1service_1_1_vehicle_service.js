var interfacecom_1_1pz1_1_1pai_1_1vehicle_1_1service_1_1_vehicle_service =
[
    [ "deleteVehicle", "interfacecom_1_1pz1_1_1pai_1_1vehicle_1_1service_1_1_vehicle_service.html#a9f04027b4a5f01831a4812752d8ae0a5", null ],
    [ "existById", "interfacecom_1_1pz1_1_1pai_1_1vehicle_1_1service_1_1_vehicle_service.html#a40728ee1aaa70e633fca6d20b5e274f0", null ],
    [ "readAllVehicles", "interfacecom_1_1pz1_1_1pai_1_1vehicle_1_1service_1_1_vehicle_service.html#a21f83e773d188b2e6ee7b5aa5c5d583a", null ],
    [ "readAllVehicles", "interfacecom_1_1pz1_1_1pai_1_1vehicle_1_1service_1_1_vehicle_service.html#aeacfe26277e87350938a6f45971a53bc", null ],
    [ "readVehicle", "interfacecom_1_1pz1_1_1pai_1_1vehicle_1_1service_1_1_vehicle_service.html#a10956fe28edb2bdc8348b6ccc8780a71", null ],
    [ "saveVehicle", "interfacecom_1_1pz1_1_1pai_1_1vehicle_1_1service_1_1_vehicle_service.html#ad88c393eedd019c9124c8684e7088a01", null ],
    [ "updateVehicle", "interfacecom_1_1pz1_1_1pai_1_1vehicle_1_1service_1_1_vehicle_service.html#af860a34f7d65b25c41946ec9c47a1fcd", null ]
];