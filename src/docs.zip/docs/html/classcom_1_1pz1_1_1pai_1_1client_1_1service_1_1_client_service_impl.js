var classcom_1_1pz1_1_1pai_1_1client_1_1service_1_1_client_service_impl =
[
    [ "deleteClient", "classcom_1_1pz1_1_1pai_1_1client_1_1service_1_1_client_service_impl.html#a8f8b55c4b5f6497e06d40e52f50b066b", null ],
    [ "getAllClients", "classcom_1_1pz1_1_1pai_1_1client_1_1service_1_1_client_service_impl.html#a16928aaca93e93b3d91499748caf8c71", null ],
    [ "getAllClients", "classcom_1_1pz1_1_1pai_1_1client_1_1service_1_1_client_service_impl.html#a61b44acfae6d65586d74c025093c532e", null ],
    [ "getClient", "classcom_1_1pz1_1_1pai_1_1client_1_1service_1_1_client_service_impl.html#acc663d80a7dc08074ae443b71a625982", null ],
    [ "saveClient", "classcom_1_1pz1_1_1pai_1_1client_1_1service_1_1_client_service_impl.html#afd455c7ca92f7d26efbdfe1ecf19885d", null ],
    [ "updateClient", "classcom_1_1pz1_1_1pai_1_1client_1_1service_1_1_client_service_impl.html#a6094b50da1476a4008e77d2e8dcbf2b0", null ]
];