var dir_2e74928c55c47d7228a814619ceb6d60 =
[
    [ "ClientRepository.java", "_client_repository_8java.html", "_client_repository_8java" ]
];