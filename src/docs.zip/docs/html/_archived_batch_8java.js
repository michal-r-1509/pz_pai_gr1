var _archived_batch_8java =
[
    [ "com.pz1.pai.archive.domain.ArchivedBatch", "classcom_1_1pz1_1_1pai_1_1archive_1_1domain_1_1_archived_batch.html", null ]
];