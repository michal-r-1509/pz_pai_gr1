var namespacecom_1_1pz1_1_1pai_1_1exceptions =
[
    [ "ElementConflictException", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_element_conflict_exception.html", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_element_conflict_exception" ],
    [ "ElementNotFoundException", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_element_not_found_exception.html", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_element_not_found_exception" ],
    [ "GlobalExceptionHandler", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_global_exception_handler.html", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_global_exception_handler" ],
    [ "IllegalOperationException", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_illegal_operation_exception.html", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_illegal_operation_exception" ],
    [ "TaxpayerIdentityNumberException", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_taxpayer_identity_number_exception.html", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_taxpayer_identity_number_exception" ]
];