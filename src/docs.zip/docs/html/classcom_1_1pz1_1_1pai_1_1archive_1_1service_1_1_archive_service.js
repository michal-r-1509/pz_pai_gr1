var classcom_1_1pz1_1_1pai_1_1archive_1_1service_1_1_archive_service =
[
    [ "readAllArchivedBatches", "classcom_1_1pz1_1_1pai_1_1archive_1_1service_1_1_archive_service.html#aa9f9157828841c32d38933327fecf9b4", null ],
    [ "readAllArchivedBatches", "classcom_1_1pz1_1_1pai_1_1archive_1_1service_1_1_archive_service.html#ab19306e823cdbcb206a2d9e9fd01ea6d", null ],
    [ "saveToArchive", "classcom_1_1pz1_1_1pai_1_1archive_1_1service_1_1_archive_service.html#adeaadc0ebebc4b03940e4ecb473a98a1", null ]
];