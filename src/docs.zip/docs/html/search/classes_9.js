var searchData=
[
  ['taxpayeridentitynumberexception_0',['TaxpayerIdentityNumberException',['../classcom_1_1pz1_1_1pai_1_1exceptions_1_1_taxpayer_identity_number_exception.html',1,'com::pz1::pai::exceptions']]]
];
