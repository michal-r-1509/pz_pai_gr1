var searchData=
[
  ['changeorderstatus_0',['changeOrderStatus',['../interfacecom_1_1pz1_1_1pai_1_1order_1_1service_1_1_order_service.html#a710d254b7ed5d5069930e109590a42c3',1,'com.pz1.pai.order.service.OrderService.changeOrderStatus()'],['../classcom_1_1pz1_1_1pai_1_1order_1_1service_1_1_order_service_impl.html#a58d49a3d930f4cc1d814cbf7988af74a',1,'com.pz1.pai.order.service.OrderServiceImpl.changeOrderStatus()']]],
  ['changingorderstatus_1',['changingOrderStatus',['../classcom_1_1pz1_1_1pai_1_1order_1_1event_1_1_order_status.html#a9049dec80c0588c5e9424355997d5656',1,'com::pz1::pai::order::event::OrderStatus']]],
  ['clienttype_2',['clientType',['../classcom_1_1pz1_1_1pai_1_1client_1_1tool_1_1_client_mapper.html#a03b614bcc0d5544e5f516cdc412c2705',1,'com::pz1::pai::client::tool::ClientMapper']]]
];
