var _base_entity_8java =
[
    [ "com.pz1.pai.shared.BaseEntity", "classcom_1_1pz1_1_1pai_1_1shared_1_1_base_entity.html", null ]
];