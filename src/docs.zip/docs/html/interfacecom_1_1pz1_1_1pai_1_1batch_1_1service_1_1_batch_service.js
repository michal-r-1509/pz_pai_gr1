var interfacecom_1_1pz1_1_1pai_1_1batch_1_1service_1_1_batch_service =
[
    [ "deleteBatch", "interfacecom_1_1pz1_1_1pai_1_1batch_1_1service_1_1_batch_service.html#a31a14f5855097a6c4e7aecee5001cb00", null ],
    [ "inverseStatus", "interfacecom_1_1pz1_1_1pai_1_1batch_1_1service_1_1_batch_service.html#ad37cb72af1a7a0b7174d76c03be14eda", null ],
    [ "readAllBatches", "interfacecom_1_1pz1_1_1pai_1_1batch_1_1service_1_1_batch_service.html#a226aa28ce1354b52ac2202a9597025dd", null ],
    [ "readAllBatches", "interfacecom_1_1pz1_1_1pai_1_1batch_1_1service_1_1_batch_service.html#a5551ab5a7a1f3d73ebc29885b1ac8fe0", null ],
    [ "readAllBatchesByOrderId", "interfacecom_1_1pz1_1_1pai_1_1batch_1_1service_1_1_batch_service.html#a08a3beab2b0d5a83ef7ea8dfd0ab0849", null ],
    [ "readBatch", "interfacecom_1_1pz1_1_1pai_1_1batch_1_1service_1_1_batch_service.html#aeaa4eb1246eb1e2712aec16c0217e9dd", null ],
    [ "readBatchToDnPrint", "interfacecom_1_1pz1_1_1pai_1_1batch_1_1service_1_1_batch_service.html#a1dc6b881b40b2e2083e4e7755a4b244d", null ]
];