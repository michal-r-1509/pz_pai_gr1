var enumcom_1_1pz1_1_1pai_1_1client_1_1tool_1_1_client_type =
[
    [ "BUSINESS", "enumcom_1_1pz1_1_1pai_1_1client_1_1tool_1_1_client_type.html#aa082b65932143874cbac6aa19c7afd3b", null ],
    [ "INDIVIDUAL", "enumcom_1_1pz1_1_1pai_1_1client_1_1tool_1_1_client_type.html#a48ea6c8c63ef3fcfb56473b0f05f9568", null ]
];