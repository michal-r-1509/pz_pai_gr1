var dir_76382ef17f1e5bbc980c1760136d645c =
[
    [ "OrderRequestDTO.java", "_order_request_d_t_o_8java.html", "_order_request_d_t_o_8java" ],
    [ "OrderResponseDTO.java", "_order_response_d_t_o_8java.html", "_order_response_d_t_o_8java" ]
];