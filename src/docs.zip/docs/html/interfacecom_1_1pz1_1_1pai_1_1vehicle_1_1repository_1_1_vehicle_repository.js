var interfacecom_1_1pz1_1_1pai_1_1vehicle_1_1repository_1_1_vehicle_repository =
[
    [ "existsByRegNo", "interfacecom_1_1pz1_1_1pai_1_1vehicle_1_1repository_1_1_vehicle_repository.html#a34cc54032d74286c2cc209ca0b981224", null ],
    [ "existsByRegNoAndIdIsNot", "interfacecom_1_1pz1_1_1pai_1_1vehicle_1_1repository_1_1_vehicle_repository.html#abcb779e49f35d4dfdd36865661a343fd", null ]
];