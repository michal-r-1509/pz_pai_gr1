var namespacecom_1_1pz1_1_1pai_1_1batch_1_1service =
[
    [ "BatchService", "interfacecom_1_1pz1_1_1pai_1_1batch_1_1service_1_1_batch_service.html", "interfacecom_1_1pz1_1_1pai_1_1batch_1_1service_1_1_batch_service" ],
    [ "BatchServiceImpl", "classcom_1_1pz1_1_1pai_1_1batch_1_1service_1_1_batch_service_impl.html", "classcom_1_1pz1_1_1pai_1_1batch_1_1service_1_1_batch_service_impl" ]
];