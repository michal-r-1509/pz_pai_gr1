var namespaces_dup =
[
    [ "com", null, [
      [ "pz1", null, [
        [ "pai", "namespacecom_1_1pz1_1_1pai.html", "namespacecom_1_1pz1_1_1pai" ]
      ] ]
    ] ]
];