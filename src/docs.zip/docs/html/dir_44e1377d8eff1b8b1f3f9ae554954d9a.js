var dir_44e1377d8eff1b8b1f3f9ae554954d9a =
[
    [ "Vehicle.java", "_vehicle_8java.html", "_vehicle_8java" ],
    [ "VehicleType.java", "_vehicle_type_8java.html", "_vehicle_type_8java" ]
];