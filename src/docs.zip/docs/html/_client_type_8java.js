var _client_type_8java =
[
    [ "com.pz1.pai.client.tool.ClientType", "enumcom_1_1pz1_1_1pai_1_1client_1_1tool_1_1_client_type.html", "enumcom_1_1pz1_1_1pai_1_1client_1_1tool_1_1_client_type" ]
];