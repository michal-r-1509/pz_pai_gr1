var interfacecom_1_1pz1_1_1pai_1_1order_1_1service_1_1_order_service =
[
    [ "changeOrderStatus", "interfacecom_1_1pz1_1_1pai_1_1order_1_1service_1_1_order_service.html#a710d254b7ed5d5069930e109590a42c3", null ],
    [ "deleteOrder", "interfacecom_1_1pz1_1_1pai_1_1order_1_1service_1_1_order_service.html#a0a1c2ce0b6ef36d4139bbe7ebd3f633d", null ],
    [ "getAllOrders", "interfacecom_1_1pz1_1_1pai_1_1order_1_1service_1_1_order_service.html#a8833bf5230ffc39becb55baa8c4c2281", null ],
    [ "getAllOrders", "interfacecom_1_1pz1_1_1pai_1_1order_1_1service_1_1_order_service.html#aeba0479a71503f1bf918bc1e6de1d846", null ],
    [ "getAllOrdersByState", "interfacecom_1_1pz1_1_1pai_1_1order_1_1service_1_1_order_service.html#a5c62bcad177ef30287d111ac877ce2c8", null ],
    [ "getOrder", "interfacecom_1_1pz1_1_1pai_1_1order_1_1service_1_1_order_service.html#a707b47efa84eb19dc22f6dd0f3d969d0", null ],
    [ "saveOrder", "interfacecom_1_1pz1_1_1pai_1_1order_1_1service_1_1_order_service.html#a12b93dcd252317f8fe89cf5c0fad626c", null ],
    [ "saveOrUpdateBatches", "interfacecom_1_1pz1_1_1pai_1_1order_1_1service_1_1_order_service.html#a1f26234861d96319c2a9d37e0edabd27", null ],
    [ "updateOrder", "interfacecom_1_1pz1_1_1pai_1_1order_1_1service_1_1_order_service.html#a2e5e26ed3135e5c56879ecce1cd46bbd", null ]
];