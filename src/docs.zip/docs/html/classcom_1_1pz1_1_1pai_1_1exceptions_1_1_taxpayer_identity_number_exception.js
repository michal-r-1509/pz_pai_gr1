var classcom_1_1pz1_1_1pai_1_1exceptions_1_1_taxpayer_identity_number_exception =
[
    [ "TaxpayerIdentityNumberException", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_taxpayer_identity_number_exception.html#ae6ad4206f5ff1c0f0313ef7aadbfeac3", null ]
];