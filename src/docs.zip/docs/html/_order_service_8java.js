var _order_service_8java =
[
    [ "com.pz1.pai.order.service.OrderService", "interfacecom_1_1pz1_1_1pai_1_1order_1_1service_1_1_order_service.html", "interfacecom_1_1pz1_1_1pai_1_1order_1_1service_1_1_order_service" ]
];