var namespacecom_1_1pz1_1_1pai_1_1archive_1_1repository =
[
    [ "ArchiveRepository", "interfacecom_1_1pz1_1_1pai_1_1archive_1_1repository_1_1_archive_repository.html", null ]
];