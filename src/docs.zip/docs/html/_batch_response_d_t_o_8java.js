var _batch_response_d_t_o_8java =
[
    [ "com.pz1.pai.batch.dto.BatchResponseDTO", "classcom_1_1pz1_1_1pai_1_1batch_1_1dto_1_1_batch_response_d_t_o.html", null ]
];