var namespacecom_1_1pz1_1_1pai_1_1vehicle_1_1dto =
[
    [ "VehicleRequestDTO", "classcom_1_1pz1_1_1pai_1_1vehicle_1_1dto_1_1_vehicle_request_d_t_o.html", null ]
];