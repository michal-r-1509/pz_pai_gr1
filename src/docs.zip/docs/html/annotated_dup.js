var annotated_dup =
[
    [ "com", null, [
      [ "pz1", null, [
        [ "pai", "namespacecom_1_1pz1_1_1pai.html", [
          [ "archive", null, [
            [ "controller", "namespacecom_1_1pz1_1_1pai_1_1archive_1_1controller.html", [
              [ "ArchiveController", "classcom_1_1pz1_1_1pai_1_1archive_1_1controller_1_1_archive_controller.html", null ]
            ] ],
            [ "domain", "namespacecom_1_1pz1_1_1pai_1_1archive_1_1domain.html", [
              [ "ArchivedBatch", "classcom_1_1pz1_1_1pai_1_1archive_1_1domain_1_1_archived_batch.html", null ]
            ] ],
            [ "repository", "namespacecom_1_1pz1_1_1pai_1_1archive_1_1repository.html", [
              [ "ArchiveRepository", "interfacecom_1_1pz1_1_1pai_1_1archive_1_1repository_1_1_archive_repository.html", null ]
            ] ],
            [ "service", "namespacecom_1_1pz1_1_1pai_1_1archive_1_1service.html", [
              [ "ArchiveService", "classcom_1_1pz1_1_1pai_1_1archive_1_1service_1_1_archive_service.html", "classcom_1_1pz1_1_1pai_1_1archive_1_1service_1_1_archive_service" ]
            ] ],
            [ "tool", "namespacecom_1_1pz1_1_1pai_1_1archive_1_1tool.html", [
              [ "ArchiveMapper", "classcom_1_1pz1_1_1pai_1_1archive_1_1tool_1_1_archive_mapper.html", "classcom_1_1pz1_1_1pai_1_1archive_1_1tool_1_1_archive_mapper" ]
            ] ]
          ] ],
          [ "batch", null, [
            [ "controller", "namespacecom_1_1pz1_1_1pai_1_1batch_1_1controller.html", [
              [ "BatchController", "classcom_1_1pz1_1_1pai_1_1batch_1_1controller_1_1_batch_controller.html", null ]
            ] ],
            [ "domain", "namespacecom_1_1pz1_1_1pai_1_1batch_1_1domain.html", [
              [ "Batch", "classcom_1_1pz1_1_1pai_1_1batch_1_1domain_1_1_batch.html", null ]
            ] ],
            [ "dto", "namespacecom_1_1pz1_1_1pai_1_1batch_1_1dto.html", [
              [ "BatchDnPrintDTO", "classcom_1_1pz1_1_1pai_1_1batch_1_1dto_1_1_batch_dn_print_d_t_o.html", null ],
              [ "BatchRequestDTO", "classcom_1_1pz1_1_1pai_1_1batch_1_1dto_1_1_batch_request_d_t_o.html", null ],
              [ "BatchResponseDTO", "classcom_1_1pz1_1_1pai_1_1batch_1_1dto_1_1_batch_response_d_t_o.html", null ]
            ] ],
            [ "repository", "namespacecom_1_1pz1_1_1pai_1_1batch_1_1repository.html", [
              [ "BatchRepository", "interfacecom_1_1pz1_1_1pai_1_1batch_1_1repository_1_1_batch_repository.html", "interfacecom_1_1pz1_1_1pai_1_1batch_1_1repository_1_1_batch_repository" ]
            ] ],
            [ "service", "namespacecom_1_1pz1_1_1pai_1_1batch_1_1service.html", [
              [ "BatchService", "interfacecom_1_1pz1_1_1pai_1_1batch_1_1service_1_1_batch_service.html", "interfacecom_1_1pz1_1_1pai_1_1batch_1_1service_1_1_batch_service" ],
              [ "BatchServiceImpl", "classcom_1_1pz1_1_1pai_1_1batch_1_1service_1_1_batch_service_impl.html", "classcom_1_1pz1_1_1pai_1_1batch_1_1service_1_1_batch_service_impl" ]
            ] ],
            [ "tool", "namespacecom_1_1pz1_1_1pai_1_1batch_1_1tool.html", [
              [ "BatchMapper", "classcom_1_1pz1_1_1pai_1_1batch_1_1tool_1_1_batch_mapper.html", "classcom_1_1pz1_1_1pai_1_1batch_1_1tool_1_1_batch_mapper" ],
              [ "BatchValidator", "classcom_1_1pz1_1_1pai_1_1batch_1_1tool_1_1_batch_validator.html", "classcom_1_1pz1_1_1pai_1_1batch_1_1tool_1_1_batch_validator" ],
              [ "ScheduleMapper", "classcom_1_1pz1_1_1pai_1_1batch_1_1tool_1_1_schedule_mapper.html", "classcom_1_1pz1_1_1pai_1_1batch_1_1tool_1_1_schedule_mapper" ]
            ] ]
          ] ],
          [ "client", null, [
            [ "controller", "namespacecom_1_1pz1_1_1pai_1_1client_1_1controller.html", [
              [ "ClientController", "classcom_1_1pz1_1_1pai_1_1client_1_1controller_1_1_client_controller.html", null ]
            ] ],
            [ "domain", "namespacecom_1_1pz1_1_1pai_1_1client_1_1domain.html", [
              [ "Client", "classcom_1_1pz1_1_1pai_1_1client_1_1domain_1_1_client.html", null ]
            ] ],
            [ "repository", "namespacecom_1_1pz1_1_1pai_1_1client_1_1repository.html", [
              [ "ClientRepository", "interfacecom_1_1pz1_1_1pai_1_1client_1_1repository_1_1_client_repository.html", "interfacecom_1_1pz1_1_1pai_1_1client_1_1repository_1_1_client_repository" ]
            ] ],
            [ "service", "namespacecom_1_1pz1_1_1pai_1_1client_1_1service.html", [
              [ "ClientService", "interfacecom_1_1pz1_1_1pai_1_1client_1_1service_1_1_client_service.html", "interfacecom_1_1pz1_1_1pai_1_1client_1_1service_1_1_client_service" ],
              [ "ClientServiceImpl", "classcom_1_1pz1_1_1pai_1_1client_1_1service_1_1_client_service_impl.html", "classcom_1_1pz1_1_1pai_1_1client_1_1service_1_1_client_service_impl" ]
            ] ],
            [ "tool", "namespacecom_1_1pz1_1_1pai_1_1client_1_1tool.html", [
              [ "ClientMapper", "classcom_1_1pz1_1_1pai_1_1client_1_1tool_1_1_client_mapper.html", "classcom_1_1pz1_1_1pai_1_1client_1_1tool_1_1_client_mapper" ],
              [ "ClientType", "enumcom_1_1pz1_1_1pai_1_1client_1_1tool_1_1_client_type.html", "enumcom_1_1pz1_1_1pai_1_1client_1_1tool_1_1_client_type" ]
            ] ]
          ] ],
          [ "exceptions", "namespacecom_1_1pz1_1_1pai_1_1exceptions.html", [
            [ "ElementConflictException", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_element_conflict_exception.html", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_element_conflict_exception" ],
            [ "ElementNotFoundException", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_element_not_found_exception.html", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_element_not_found_exception" ],
            [ "GlobalExceptionHandler", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_global_exception_handler.html", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_global_exception_handler" ],
            [ "IllegalOperationException", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_illegal_operation_exception.html", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_illegal_operation_exception" ],
            [ "TaxpayerIdentityNumberException", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_taxpayer_identity_number_exception.html", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_taxpayer_identity_number_exception" ]
          ] ],
          [ "order", null, [
            [ "domain", "namespacecom_1_1pz1_1_1pai_1_1order_1_1domain.html", [
              [ "Order", "classcom_1_1pz1_1_1pai_1_1order_1_1domain_1_1_order.html", null ]
            ] ],
            [ "dto", "namespacecom_1_1pz1_1_1pai_1_1order_1_1dto.html", [
              [ "OrderRequestDTO", "classcom_1_1pz1_1_1pai_1_1order_1_1dto_1_1_order_request_d_t_o.html", null ],
              [ "OrderResponseDTO", "classcom_1_1pz1_1_1pai_1_1order_1_1dto_1_1_order_response_d_t_o.html", null ]
            ] ],
            [ "event", "namespacecom_1_1pz1_1_1pai_1_1order_1_1event.html", [
              [ "OrderStatus", "classcom_1_1pz1_1_1pai_1_1order_1_1event_1_1_order_status.html", "classcom_1_1pz1_1_1pai_1_1order_1_1event_1_1_order_status" ]
            ] ],
            [ "repository", "namespacecom_1_1pz1_1_1pai_1_1order_1_1repository.html", [
              [ "OrderRepository", "interfacecom_1_1pz1_1_1pai_1_1order_1_1repository_1_1_order_repository.html", "interfacecom_1_1pz1_1_1pai_1_1order_1_1repository_1_1_order_repository" ]
            ] ],
            [ "service", "namespacecom_1_1pz1_1_1pai_1_1order_1_1service.html", [
              [ "OrderService", "interfacecom_1_1pz1_1_1pai_1_1order_1_1service_1_1_order_service.html", "interfacecom_1_1pz1_1_1pai_1_1order_1_1service_1_1_order_service" ],
              [ "OrderServiceImpl", "classcom_1_1pz1_1_1pai_1_1order_1_1service_1_1_order_service_impl.html", "classcom_1_1pz1_1_1pai_1_1order_1_1service_1_1_order_service_impl" ]
            ] ],
            [ "tool", "namespacecom_1_1pz1_1_1pai_1_1order_1_1tool.html", [
              [ "OrderMapper", "classcom_1_1pz1_1_1pai_1_1order_1_1tool_1_1_order_mapper.html", "classcom_1_1pz1_1_1pai_1_1order_1_1tool_1_1_order_mapper" ]
            ] ]
          ] ],
          [ "schedule", null, [
            [ "domain", "namespacecom_1_1pz1_1_1pai_1_1schedule_1_1domain.html", [
              [ "Schedule", "classcom_1_1pz1_1_1pai_1_1schedule_1_1domain_1_1_schedule.html", null ]
            ] ],
            [ "repository", "namespacecom_1_1pz1_1_1pai_1_1schedule_1_1repository.html", [
              [ "ScheduleRepository", "interfacecom_1_1pz1_1_1pai_1_1schedule_1_1repository_1_1_schedule_repository.html", "interfacecom_1_1pz1_1_1pai_1_1schedule_1_1repository_1_1_schedule_repository" ]
            ] ],
            [ "service", "namespacecom_1_1pz1_1_1pai_1_1schedule_1_1service.html", [
              [ "ScheduleService", "interfacecom_1_1pz1_1_1pai_1_1schedule_1_1service_1_1_schedule_service.html", "interfacecom_1_1pz1_1_1pai_1_1schedule_1_1service_1_1_schedule_service" ],
              [ "ScheduleServiceImpl", "classcom_1_1pz1_1_1pai_1_1schedule_1_1service_1_1_schedule_service_impl.html", "classcom_1_1pz1_1_1pai_1_1schedule_1_1service_1_1_schedule_service_impl" ]
            ] ]
          ] ],
          [ "shared", "namespacecom_1_1pz1_1_1pai_1_1shared.html", [
            [ "BaseEntity", "classcom_1_1pz1_1_1pai_1_1shared_1_1_base_entity.html", null ]
          ] ],
          [ "vehicle", null, [
            [ "domain", "namespacecom_1_1pz1_1_1pai_1_1vehicle_1_1domain.html", [
              [ "Vehicle", "classcom_1_1pz1_1_1pai_1_1vehicle_1_1domain_1_1_vehicle.html", null ],
              [ "VehicleType", "enumcom_1_1pz1_1_1pai_1_1vehicle_1_1domain_1_1_vehicle_type.html", "enumcom_1_1pz1_1_1pai_1_1vehicle_1_1domain_1_1_vehicle_type" ]
            ] ],
            [ "dto", "namespacecom_1_1pz1_1_1pai_1_1vehicle_1_1dto.html", [
              [ "VehicleRequestDTO", "classcom_1_1pz1_1_1pai_1_1vehicle_1_1dto_1_1_vehicle_request_d_t_o.html", null ]
            ] ],
            [ "repository", "namespacecom_1_1pz1_1_1pai_1_1vehicle_1_1repository.html", [
              [ "VehicleRepository", "interfacecom_1_1pz1_1_1pai_1_1vehicle_1_1repository_1_1_vehicle_repository.html", "interfacecom_1_1pz1_1_1pai_1_1vehicle_1_1repository_1_1_vehicle_repository" ]
            ] ],
            [ "service", "namespacecom_1_1pz1_1_1pai_1_1vehicle_1_1service.html", [
              [ "VehicleService", "interfacecom_1_1pz1_1_1pai_1_1vehicle_1_1service_1_1_vehicle_service.html", "interfacecom_1_1pz1_1_1pai_1_1vehicle_1_1service_1_1_vehicle_service" ],
              [ "VehicleServiceImpl", "classcom_1_1pz1_1_1pai_1_1vehicle_1_1service_1_1_vehicle_service_impl.html", "classcom_1_1pz1_1_1pai_1_1vehicle_1_1service_1_1_vehicle_service_impl" ]
            ] ],
            [ "tool", "namespacecom_1_1pz1_1_1pai_1_1vehicle_1_1tool.html", [
              [ "VehicleMapper", "classcom_1_1pz1_1_1pai_1_1vehicle_1_1tool_1_1_vehicle_mapper.html", "classcom_1_1pz1_1_1pai_1_1vehicle_1_1tool_1_1_vehicle_mapper" ]
            ] ]
          ] ],
          [ "PaiApplication", "classcom_1_1pz1_1_1pai_1_1_pai_application.html", null ]
        ] ]
      ] ]
    ] ]
];