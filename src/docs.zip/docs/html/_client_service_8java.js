var _client_service_8java =
[
    [ "com.pz1.pai.client.service.ClientService", "interfacecom_1_1pz1_1_1pai_1_1client_1_1service_1_1_client_service.html", "interfacecom_1_1pz1_1_1pai_1_1client_1_1service_1_1_client_service" ]
];