var dir_132920e9bff29dd03ea4fa2defed0c0f =
[
    [ "ClientService.java", "_client_service_8java.html", "_client_service_8java" ],
    [ "ClientServiceImpl.java", "_client_service_impl_8java.html", "_client_service_impl_8java" ]
];