var _illegal_operation_exception_8java =
[
    [ "com.pz1.pai.exceptions.IllegalOperationException", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_illegal_operation_exception.html", "classcom_1_1pz1_1_1pai_1_1exceptions_1_1_illegal_operation_exception" ]
];