var _client_service_impl_8java =
[
    [ "com.pz1.pai.client.service.ClientServiceImpl", "classcom_1_1pz1_1_1pai_1_1client_1_1service_1_1_client_service_impl.html", "classcom_1_1pz1_1_1pai_1_1client_1_1service_1_1_client_service_impl" ]
];